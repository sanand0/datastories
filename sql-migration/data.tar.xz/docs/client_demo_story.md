# Client demo storyboard (optional)

Hook: “Migration isn’t a search/replace problem. It’s a risk-management + proof problem.”

Act 1 — Workload reality:
- Show that a small set of scripts accounts for most production cost.

Act 2 — Conversion:
- Simple script: TOP → LIMIT
- Structural rewrite: PIVOT or MERGE
- Routine conversion: TRY/CATCH → handlers + transaction control

Act 3 — Proof & governance:
- Telemetry (attempts, token use, pass/fail)
- Manual review hotspots as an auditable list

Close: “The agent accelerates the boring 80%, and highlights the risky 20% — with evidence.”
