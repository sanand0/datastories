# MSSQL → MySQL conversion rules (demo cheat sheet)

This pack supports a client-facing demo of an LLM + coding-agent workflow for migrating SQL Server (T‑SQL) scripts to MySQL.

## Typical mapping patterns
- `SELECT TOP (n)` → `LIMIT n` (watch out for nested queries and `ORDER BY`)
- `GETDATE()` / `SYSDATETIME()` → `NOW()` / `NOW(3)`
- `NEWID()` → `UUID()`
- `ISNULL(a,b)` → `IFNULL(a,b)`
- `STRING_AGG(x, ',')` → `GROUP_CONCAT(x SEPARATOR ',')` (watch `group_concat_max_len`)
- `DATEADD(part, n, dt)` → `DATE_ADD(dt, INTERVAL n <UNIT>)`
- `DATEDIFF(part, a, b)` → `TIMESTAMPDIFF(<UNIT>, a, b)`
- `IDENTITY(1,1)` → `AUTO_INCREMENT`

## Common “gotchas” (great for showing LLM value)
- `UPDATE ... FROM ...` rewrites: MySQL uses `UPDATE t JOIN (...) x ON ... SET ...`
- `MERGE` rewrites: MySQL uses `INSERT ... ON DUPLICATE KEY UPDATE` (requires keys)
- `PIVOT` rewrites: conditional aggregation (`SUM(CASE WHEN ... THEN ... END)`)
- `CROSS APPLY` patterns: often need normalization, `JSON_TABLE`, or alternate SQL
- `TRY/CATCH`, `RAISERROR`: convert to handlers + `SIGNAL` / `RESIGNAL`
- Hints like `WITH (NOLOCK)`: remove; decide on transaction isolation instead
- Data types: `NVARCHAR(MAX)` → `LONGTEXT`, `MONEY` → `DECIMAL(19,4)`, `UNIQUEIDENTIFIER` → `CHAR(36)`
- Collation & case-sensitivity differences can change behavior subtly.

## What the “agent” should do (demo narrative)
1. Classify script and detect risky features (`MERGE`, `PIVOT`, dynamic SQL…)
2. Convert using rules + LLM translation for structural rewrites
3. Run lint + unit tests (syntax, schema alignment, row-count sanity checks)
4. Flag manual review hotspots with concrete suggestions (keys, indexing, semantics)
5. Produce an audit trail: diffs, token usage, test results, and time saved.
