## Task
Convert this MSSQL script to MySQL 8.0+.

## Input MSSQL
```sql
{{MSSQL_SQL_HERE}}
```

## Output format
1) MySQL script in a fenced ```sql``` block  
2) Bullet list: “Risks / manual review hotspots”  
3) Bullet list: “Suggested validation tests”
