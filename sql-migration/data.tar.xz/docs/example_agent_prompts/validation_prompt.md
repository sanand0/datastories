You are reviewing a MSSQL→MySQL conversion.

Compare:
- query intent and result columns
- filtering semantics (NULL handling, date math, collation/case-sensitivity)
- transaction/locking assumptions
- performance considerations (indexes, join order, grouping)

Produce:
- a checklist of tests (row counts, edge cases, sampled comparisons)
- any recommended schema/index changes
