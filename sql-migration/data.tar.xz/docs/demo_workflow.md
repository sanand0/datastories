# Demo workflow: LLM + coding agents for MSSQL → MySQL migration

## What’s in this pack
- **100 MSSQL scripts**: `scripts/mssql/`
- **100 MySQL counterparts**: `scripts/mysql/`
- **Schema scripts** (both dialects): `schema/`
- **Execution logs (one month)**: `logs/execution_log.csv`
- **Conversion telemetry**: `logs/conversion_runs.csv`
- **Manifest / metadata**: `logs/scripts_manifest.csv`, `manifest.json`, `logs/impact_analysis.json`
- **Natural-language prompts**: `logs/nl_prompts.jsonl`

## Suggested “client story”
Migration isn’t just syntax conversion. It’s:
- understanding the *real* workload (which scripts run, how often, where it hurts)
- translating semantic differences safely
- proving equivalence with tests and traceability.

## A clean demo sequence (15 minutes)
1. Workload triage: open `logs/execution_log.csv` and show which scripts dominate runtime.
2. Impact analysis: open `logs/impact_analysis.json` to show table hot-spots.
3. Pick 3 scripts:
   - a simple `TOP` query (auto-converts)
   - a `PIVOT` / `MERGE` script (needs structural rewrite)
   - a stored procedure with `TRY/CATCH` (needs handler rewrite)
4. Agent conversion loop: classify → convert → test → iterate.
   Use `logs/conversion_runs.csv` as the audit trail.
5. Wrap up: faster inventory + conversion at scale, and deliberate manual-review flagging.

Tip: The persuasive moment is when the agent *does not pretend everything is trivial*.
