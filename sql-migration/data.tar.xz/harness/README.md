# Harness (optional)

This folder intentionally stays lightweight for the synthetic demo pack.

If you want to extend this into a runnable demo:
- Load `schema/mysql/*.sql` into a MySQL 8 instance.
- Generate small synthetic data (not included here to keep the pack small).
- Execute `scripts/mysql/*.sql` and compare outputs against MSSQL baselines.

For client demos, you can often avoid running a full database by focusing on:
- conversion diffs
- risk classification
- log-driven prioritization
- test-plan generation
