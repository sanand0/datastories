/*
  ScriptID: 0048
  Title: Quick look: Payments rows
  Category: query
  Complexity: 2/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (10) [PaymentMethod], [OrderID], [TxnRef], [PaymentID], [Amount], [Status]
FROM [dbo].[Payments]
WHERE [Status] = 'Captured'
ORDER BY 1 DESC;
