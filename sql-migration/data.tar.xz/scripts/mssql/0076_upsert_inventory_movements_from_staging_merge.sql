/*
  ScriptID: 0076
  Title: Upsert inventory movements from staging (MERGE)
  Category: etl
  Complexity: 8/10
  Tags: MERGE, ETL, upsert
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

-- Assume staging table [dbo].[StgInventoryMovements] is populated from files.
MERGE [dbo].[InventoryMovements] AS tgt
USING (
    SELECT [ProductID],[StoreID],[MovementType],[Quantity],[MovedAt],[Reference]
    FROM [dbo].[StgInventoryMovements]
) AS src
ON tgt.[ProductID] = src.[ProductID]
   AND tgt.[StoreID] = src.[StoreID]
   AND tgt.[MovedAt] = src.[MovedAt]
   AND ISNULL(tgt.[Reference],'') = ISNULL(src.[Reference],'')
WHEN MATCHED THEN
    UPDATE SET
        tgt.[Quantity] = src.[Quantity]
WHEN NOT MATCHED THEN
    INSERT ([ProductID],[StoreID],[MovementType],[Quantity],[MovedAt],[Reference])
    VALUES (src.[ProductID],src.[StoreID],src.[MovementType],src.[Quantity],src.[MovedAt],src.[Reference]);
