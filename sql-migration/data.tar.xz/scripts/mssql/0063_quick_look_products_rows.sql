/*
  ScriptID: 0063
  Title: Quick look: Products rows
  Category: query
  Complexity: 1/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (10) [CategoryID], [IsActive], [ProductName], [UnitPrice], [SKU]
FROM [dbo].[Products]
WHERE [IsActive] = 1
ORDER BY 1 DESC;
