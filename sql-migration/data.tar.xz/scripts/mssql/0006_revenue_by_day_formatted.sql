/*
  ScriptID: 0006
  Title: Revenue by day (formatted)
  Category: report
  Complexity: 5/10
  Tags: FORMAT, datetime, reporting
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT
    FORMAT(o.[OrderDate], 'yyyy-MM-dd') AS [OrderDay],
    SUM(o.[Total]) AS [Revenue]
FROM [dbo].[Orders] o
WHERE o.[OrderDate] >= DATEADD(day, -30, GETDATE())
  AND o.[OrderStatus] IN ('Paid','Shipped','Delivered')
GROUP BY FORMAT(o.[OrderDate], 'yyyy-MM-dd')
ORDER BY [OrderDay];
