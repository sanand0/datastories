/*
  ScriptID: 0023
  Title: Store sales by category (last 14 days)
  Category: report
  Complexity: 6/10
  Tags: SELECT, join, groupby, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (50)
    s.[StoreName],
    cat.[CategoryName],
    SUM(oi.[LineTotal]) AS [Revenue],
    SUM(oi.[Quantity]) AS [Units],
    COUNT(DISTINCT o.[OrderID]) AS [Orders]
FROM [dbo].[Orders] o
JOIN [dbo].[Stores] s ON s.[StoreID] = o.[StoreID]
JOIN [dbo].[OrderItems] oi ON oi.[OrderID] = o.[OrderID]
JOIN [dbo].[Products] p ON p.[ProductID] = oi.[ProductID]
JOIN [dbo].[Categories] cat ON cat.[CategoryID] = p.[CategoryID]
WHERE o.[OrderDate] >= DATEADD(day, -14, GETDATE())
  AND o.[OrderStatus] IN ('Paid','Shipped','Delivered')
  AND p.[IsActive] = 1
GROUP BY s.[StoreName], cat.[CategoryName]
ORDER BY [Revenue] DESC;
