/*
  ScriptID: 0038
  Title: Dynamic SQL: ad-hoc filter builder (sp_executesql)
  Category: query
  Complexity: 10/10
  Tags: dynamic_sql, sp_executesql
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

DECLARE @sql NVARCHAR(MAX) = N'
    SELECT TOP (50)
        o.[OrderID], o.[OrderDate], o.[Total]
    FROM [dbo].[Orders] o
    WHERE o.[OrderDate] >= @fromDate
      AND o.[OrderStatus] = @status
    ORDER BY o.[OrderDate] DESC;
';
DECLARE @params NVARCHAR(200) = N'@fromDate DATETIME2(3), @status NVARCHAR(20)';
EXEC sp_executesql @sql, @params, @fromDate = DATEADD(day, -30, SYSDATETIME()), @status = N''Paid'';
