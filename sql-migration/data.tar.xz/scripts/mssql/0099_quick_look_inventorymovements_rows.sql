/*
  ScriptID: 0099
  Title: Quick look: InventoryMovements rows
  Category: query
  Complexity: 2/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (20) [MovedAt], [ProductID], [StoreID], [MovementType], [MovementID], [Reference]
FROM [dbo].[InventoryMovements]
WHERE [MovedAt] >= DATEADD(day, -14, GETDATE())
ORDER BY 1 DESC;
