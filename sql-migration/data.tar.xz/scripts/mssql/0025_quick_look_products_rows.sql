/*
  ScriptID: 0025
  Title: Quick look: Products rows
  Category: query
  Complexity: 2/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (100) [CreatedAt], [IsActive], [ProductName], [ProductID]
FROM [dbo].[Products]
WHERE [IsActive] = 1
ORDER BY 1 DESC;
