/*
  ScriptID: 0002
  Title: Ingest order items from JSON payload (OPENJSON)
  Category: etl
  Complexity: 9/10
  Tags: OPENJSON, JSON, ETL
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

DECLARE @orderId BIGINT = 12345;
DECLARE @items NVARCHAR(MAX) = N'[
    {"ProductID": 10, "Quantity": 2, "UnitPrice": 19.99, "Discount": 0},
    {"ProductID": 12, "Quantity": 1, "UnitPrice": 249.00, "Discount": 10.00}
]';

INSERT INTO [dbo].[OrderItems]([OrderID],[ProductID],[Quantity],[UnitPrice],[Discount],[LineTotal])
SELECT
    @orderId,
    j.[ProductID],
    j.[Quantity],
    j.[UnitPrice],
    j.[Discount],
    (j.[Quantity] * j.[UnitPrice]) - j.[Discount] AS [LineTotal]
FROM OPENJSON(@items)
WITH (
    [ProductID] INT '$.ProductID',
    [Quantity] INT '$.Quantity',
    [UnitPrice] MONEY '$.UnitPrice',
    [Discount] MONEY '$.Discount'
) j;
