/*
  ScriptID: 0087
  Title: Quick look: Payments rows
  Category: query
  Complexity: 3/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (100) [PaymentMethod], [TxnRef], [Status], [OrderID], [PaymentDate]
FROM [dbo].[Payments]
WHERE [Status] = 'Captured'
ORDER BY 1 DESC;
