/*
  ScriptID: 0093
  Title: Quick look: PageViews rows
  Category: query
  Complexity: 1/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (100) [ViewedAt], [UserAgent], [CustomerID], [ViewID], [Url], [Referrer]
FROM [dbo].[PageViews]
WHERE [ViewedAt] >= DATEADD(day, -1, GETDATE())
ORDER BY 1 DESC;
