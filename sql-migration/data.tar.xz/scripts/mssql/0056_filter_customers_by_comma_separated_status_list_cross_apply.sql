/*
  ScriptID: 0056
  Title: Filter customers by comma-separated status list (CROSS APPLY + STRING_SPLIT)
  Category: query
  Complexity: 9/10
  Tags: CROSS APPLY, STRING_SPLIT, reporting
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

DECLARE @statuses NVARCHAR(200) = N'Active,Churned,Prospect';

SELECT
    c.[CustomerID], c.[FirstName], c.[LastName], c.[Status]
FROM [dbo].[Customers] c
CROSS APPLY (
    SELECT LTRIM(RTRIM(value)) AS [StatusValue]
    FROM STRING_SPLIT(@statuses, ',')
) s
WHERE c.[Status] = s.[StatusValue]
ORDER BY c.[CustomerID];
