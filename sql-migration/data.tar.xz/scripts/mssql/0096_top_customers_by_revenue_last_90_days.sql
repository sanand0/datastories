/*
  ScriptID: 0096
  Title: Top customers by revenue (last 90 days)
  Category: query
  Complexity: 6/10
  Tags: SELECT, join, aggregate, CTE, WINDOW, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

WITH recent_orders AS (
    SELECT
        o.[OrderID],
        o.[CustomerID],
        o.[OrderDate],
        o.[Total]
    FROM [dbo].[Orders] o
    WHERE o.[OrderDate] >= DATEADD(day, -90, GETDATE())
      AND o.[OrderStatus] IN ('Paid','Shipped','Delivered')
)
SELECT TOP (100)
    c.[CustomerID],
    c.[FirstName],
    c.[LastName],
    SUM(ro.[Total]) AS [Revenue],
    COUNT(DISTINCT ro.[OrderID]) AS [Orders],
    ROW_NUMBER() OVER (ORDER BY SUM(ro.[Total]) DESC) AS [RankByRevenue]
FROM recent_orders ro
JOIN [dbo].[Customers] c ON c.[CustomerID] = ro.[CustomerID]
GROUP BY c.[CustomerID], c.[FirstName], c.[LastName]
ORDER BY [Revenue] DESC;
