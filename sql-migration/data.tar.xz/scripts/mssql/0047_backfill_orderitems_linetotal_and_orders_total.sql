/*
  ScriptID: 0047
  Title: Backfill OrderItems.LineTotal and Orders.Total
  Category: maintenance
  Complexity: 5/10
  Tags: DML, maintenance, TRANSACTION
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

BEGIN TRAN;

UPDATE oi
SET oi.[LineTotal] = (oi.[Quantity] * oi.[UnitPrice]) - oi.[Discount]
FROM [dbo].[OrderItems] oi
WHERE oi.[LineTotal] IS NULL OR oi.[LineTotal] = 0;

UPDATE o
SET o.[Subtotal] = x.[Subtotal],
    o.[Tax] = x.[Tax],
    o.[Shipping] = x.[Shipping],
    o.[Total] = x.[Total]
FROM [dbo].[Orders] o
JOIN (
    SELECT
        oi.[OrderID],
        SUM(oi.[LineTotal]) AS [Subtotal],
        SUM(oi.[LineTotal]) * 0.08 AS [Tax],
        CASE WHEN SUM(oi.[LineTotal]) >= 200 THEN 0 ELSE 7.5 END AS [Shipping],
        SUM(oi.[LineTotal]) * 1.08 + CASE WHEN SUM(oi.[LineTotal]) >= 200 THEN 0 ELSE 7.5 END AS [Total]
    FROM [dbo].[OrderItems] oi
    GROUP BY oi.[OrderID]
) x ON x.[OrderID] = o.[OrderID]
WHERE o.[OrderStatus] <> 'Cancelled';

COMMIT TRAN;
