/*
  ScriptID: 0089
  Title: Ad-hoc troubleshooting query (NOLOCK)
  Category: query
  Complexity: 6/10
  Tags: NOLOCK, performance, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (100)
    o.[OrderID], o.[OrderDate], o.[OrderStatus], o.[Total]
FROM [dbo].[Orders] o WITH (NOLOCK)
WHERE o.[OrderStatus] = 'Paid'
ORDER BY o.[OrderDate] DESC;
