/*
  ScriptID: 0058
  Title: Quick look: Products rows
  Category: query
  Complexity: 3/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (10) [SKU], [CategoryID], [ProductName], [CreatedAt], [UnitPrice]
FROM [dbo].[Products]
WHERE [IsActive] = 1
ORDER BY 1 DESC;
