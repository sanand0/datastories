/*
  ScriptID: 0018
  Title: Quick look: PageViews rows
  Category: query
  Complexity: 2/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (10) [UserAgent], [Url], [ViewID], [ViewedAt]
FROM [dbo].[PageViews]
WHERE [ViewedAt] >= DATEADD(day, -1, GETDATE())
ORDER BY 1 DESC;
