/*
  ScriptID: 0014
  Title: Quick look: Customers rows
  Category: query
  Complexity: 3/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (50) [LastName], [Email], [CreatedAt], [FirstName], [Status], [Phone]
FROM [dbo].[Customers]
WHERE [Status] = 'Active' AND [CreatedAt] >= DATEADD(day, -30, GETDATE())
ORDER BY 1 DESC;
