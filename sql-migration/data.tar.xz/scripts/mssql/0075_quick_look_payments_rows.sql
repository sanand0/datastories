/*
  ScriptID: 0075
  Title: Quick look: Payments rows
  Category: query
  Complexity: 1/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (50) [PaymentMethod], [Amount], [OrderID]
FROM [dbo].[Payments]
WHERE [Status] = 'Captured'
ORDER BY 1 DESC;
