/*
  ScriptID: 0010
  Title: Monthly revenue pivot by store
  Category: report
  Complexity: 8/10
  Tags: PIVOT, reporting
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

DECLARE @year INT = YEAR(GETDATE());

SELECT *
FROM (
    SELECT
        s.[StoreName],
        MONTH(o.[OrderDate]) AS [OrderMonth],
        SUM(o.[Total]) AS [Revenue]
    FROM [dbo].[Orders] o
    JOIN [dbo].[Stores] s ON s.[StoreID] = o.[StoreID]
    WHERE YEAR(o.[OrderDate]) = @year
      AND o.[OrderStatus] IN ('Paid','Shipped','Delivered')
    GROUP BY s.[StoreName], MONTH(o.[OrderDate])
) src
PIVOT (
    SUM([Revenue]) FOR [OrderMonth] IN ([1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12])
) p
ORDER BY [StoreName];
