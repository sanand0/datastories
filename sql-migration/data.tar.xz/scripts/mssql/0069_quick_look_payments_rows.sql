/*
  ScriptID: 0069
  Title: Quick look: Payments rows
  Category: query
  Complexity: 2/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (10) [PaymentDate], [OrderID], [PaymentID], [PaymentMethod]
FROM [dbo].[Payments]
WHERE [Status] = 'Captured'
ORDER BY 1 DESC;
