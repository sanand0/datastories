/*
  ScriptID: 0034
  Title: Quick look: Payments rows
  Category: query
  Complexity: 1/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (20) [PaymentMethod], [Amount], [TxnRef], [PaymentID], [Status]
FROM [dbo].[Payments]
WHERE [Status] = 'Captured'
ORDER BY 1 DESC;
