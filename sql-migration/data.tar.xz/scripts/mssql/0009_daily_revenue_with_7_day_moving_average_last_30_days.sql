/*
  ScriptID: 0009
  Title: Daily revenue with 7-day moving average (last 30 days)
  Category: report
  Complexity: 7/10
  Tags: SELECT, CTE, WINDOW, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

WITH daily AS (
    SELECT
        CAST(o.[OrderDate] AS DATE) AS [OrderDay],
        SUM(o.[Total]) AS [Revenue]
    FROM [dbo].[Orders] o
    WHERE o.[OrderDate] >= DATEADD(day, -30, GETDATE())
      AND o.[OrderStatus] IN ('Paid','Shipped','Delivered')
    GROUP BY CAST(o.[OrderDate] AS DATE)
)
SELECT
    [OrderDay],
    [Revenue],
    AVG([Revenue]) OVER (ORDER BY [OrderDay] ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS [RevenueMA7]
FROM daily
ORDER BY [OrderDay];
