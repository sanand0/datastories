/*
  ScriptID: 0033
  Title: Quick look: PageViews rows
  Category: query
  Complexity: 3/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (20) [Referrer], [CustomerID], [Url], [ViewedAt], [UserAgent], [ViewID]
FROM [dbo].[PageViews]
WHERE [ViewedAt] >= DATEADD(day, -1, GETDATE())
ORDER BY 1 DESC;
