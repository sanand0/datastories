/*
  ScriptID: 0043
  Title: Sessionize page views into visits (#temp table)
  Category: analytics
  Complexity: 7/10
  Tags: TEMP, analytics, WINDOW
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

-- Build a temporary session table for analysis.
IF OBJECT_ID('tempdb..#pv') IS NOT NULL DROP TABLE #pv;

SELECT
    pv.[CustomerID],
    pv.[ViewedAt],
    pv.[Url],
    DATEDIFF(minute,
        LAG(pv.[ViewedAt]) OVER (PARTITION BY pv.[CustomerID] ORDER BY pv.[ViewedAt]),
        pv.[ViewedAt]
    ) AS [GapMinutes]
INTO #pv
FROM [dbo].[PageViews] pv
WHERE pv.[ViewedAt] >= DATEADD(day, -7, GETDATE());

SELECT
    [CustomerID],
    COUNT(*) AS [Views],
    SUM(CASE WHEN [GapMinutes] IS NULL OR [GapMinutes] > 30 THEN 1 ELSE 0 END) AS [EstimatedSessions]
FROM #pv
GROUP BY [CustomerID]
ORDER BY [Views] DESC;
