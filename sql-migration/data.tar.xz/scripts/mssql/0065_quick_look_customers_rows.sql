/*
  ScriptID: 0065
  Title: Quick look: Customers rows
  Category: query
  Complexity: 2/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (10) [LastName], [CustomerID], [CreatedAt], [FirstName], [Phone]
FROM [dbo].[Customers]
WHERE [Status] = 'Active' AND [CreatedAt] >= DATEADD(day, -30, GETDATE())
ORDER BY 1 DESC;
