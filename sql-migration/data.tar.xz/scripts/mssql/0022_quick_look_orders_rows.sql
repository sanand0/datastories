/*
  ScriptID: 0022
  Title: Quick look: Orders rows
  Category: query
  Complexity: 3/10
  Tags: SELECT, simple, TOP, DATEADD, IN
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (100) [OrderDate], [OrderStatus], [Subtotal], [Shipping]
FROM [dbo].[Orders]
WHERE [OrderDate] >= DATEADD(day, -7, GETDATE()) AND [OrderStatus] IN ('Paid','Shipped')
ORDER BY 1 DESC;
