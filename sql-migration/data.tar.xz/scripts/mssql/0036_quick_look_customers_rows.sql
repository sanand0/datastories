/*
  ScriptID: 0036
  Title: Quick look: Customers rows
  Category: query
  Complexity: 3/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (20) [CustomerID], [Phone], [FirstName], [LastName], [Email]
FROM [dbo].[Customers]
WHERE [Status] = 'Active' AND [CreatedAt] >= DATEADD(day, -30, GETDATE())
ORDER BY 1 DESC;
