/*
  ScriptID: 0013
  Title: Quick look: InventoryMovements rows
  Category: query
  Complexity: 1/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (50) [MovedAt], [MovementID], [Reference], [ProductID]
FROM [dbo].[InventoryMovements]
WHERE [MovedAt] >= DATEADD(day, -14, GETDATE())
ORDER BY 1 DESC;
