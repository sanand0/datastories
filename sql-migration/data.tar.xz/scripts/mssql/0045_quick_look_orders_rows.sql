/*
  ScriptID: 0045
  Title: Quick look: Orders rows
  Category: query
  Complexity: 1/10
  Tags: SELECT, simple, TOP, DATEADD, IN
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (10) [OrderDate], [CustomerID], [Total], [OrderStatus], [OrderID], [Subtotal]
FROM [dbo].[Orders]
WHERE [OrderDate] >= DATEADD(day, -7, GETDATE()) AND [OrderStatus] IN ('Paid','Shipped')
ORDER BY 1 DESC;
