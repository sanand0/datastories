/*
  ScriptID: 0066
  Title: Stored procedure: capture payment + update order status
  Category: procedure
  Complexity: 9/10
  Tags: PROC, TRY/CATCH, TRANSACTION
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

CREATE OR ALTER PROCEDURE [dbo].[sp_CapturePayment]
    @OrderID BIGINT,
    @PaymentMethod NVARCHAR(20),
    @Amount MONEY,
    @AppUser NVARCHAR(80)
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRAN;

        INSERT INTO [dbo].[Payments]([OrderID],[PaymentDate],[PaymentMethod],[Amount],[Status])
        VALUES(@OrderID, SYSDATETIME(), @PaymentMethod, @Amount, N'Captured');

        UPDATE [dbo].[Orders]
        SET [OrderStatus] = N'Paid'
        WHERE [OrderID] = @OrderID;

        EXEC sys.sp_set_session_context @key = N'app_user', @value = @AppUser;

        COMMIT TRAN;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRAN;
        DECLARE @msg NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@msg, 16, 1);
    END CATCH
END
GO
