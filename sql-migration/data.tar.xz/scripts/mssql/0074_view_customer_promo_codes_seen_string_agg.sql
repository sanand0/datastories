/*
  ScriptID: 0074
  Title: View: customer promo codes seen (STRING_AGG)
  Category: view
  Complexity: 7/10
  Tags: VIEW, STRING_AGG, reporting
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

CREATE OR ALTER VIEW [dbo].[vw_CustomerPromoCodes]
AS
SELECT
    c.[CustomerID],
    c.[Email],
    STRING_AGG(p.[PromoCode], ',') WITHIN GROUP (ORDER BY p.[PromoCode]) AS [PromoCodes]
FROM [dbo].[Customers] c
LEFT JOIN [dbo].[Promotions] p
    ON p.[IsActive] = 1
GROUP BY c.[CustomerID], c.[Email];
GO
