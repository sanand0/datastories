/*
  ScriptID: 0004
  Title: Quick look: Customers rows
  Category: query
  Complexity: 1/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT TOP (100) [FirstName], [Phone], [Status], [CustomerID]
FROM [dbo].[Customers]
WHERE [Status] = 'Active'
ORDER BY 1 DESC;
