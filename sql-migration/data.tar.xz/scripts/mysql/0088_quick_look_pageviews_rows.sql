/*
  ScriptID: 0088
  Title: Quick look: PageViews rows
  Category: query
  Complexity: 1/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `Url`, `Referrer`, `UserAgent`
FROM `PageViews`
WHERE `ViewedAt` >= DATE_ADD(NOW(, INTERVAL -1 DAY))
ORDER BY 1 DESC
LIMIT 10;
