/*
  ScriptID: 0006
  Title: Revenue by day (formatted)
  Category: report
  Complexity: 5/10
  Tags: FORMAT, datetime, reporting
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT
    DATE_FORMAT(o.`OrderDate`, '%Y-%m-%d') AS `OrderDay`,
    SUM(o.`Total`) AS `Revenue`
FROM `Orders` o
WHERE o.`OrderDate` >= DATE_SUB(NOW(), INTERVAL 30 DAY)
  AND o.`OrderStatus` IN ('Paid','Shipped','Delivered')
GROUP BY DATE_FORMAT(o.`OrderDate`, '%Y-%m-%d')
ORDER BY `OrderDay`;
