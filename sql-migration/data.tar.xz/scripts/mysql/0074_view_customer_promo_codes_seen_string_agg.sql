/*
  ScriptID: 0074
  Title: View: customer promo codes seen (GROUP_CONCAT)
  Category: view
  Complexity: 7/10
  Tags: VIEW, STRING_AGG, reporting
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

CREATE OR REPLACE VIEW `vw_CustomerPromoCodes` AS
SELECT
    c.`CustomerID`,
    c.`Email`,
    GROUP_CONCAT(p.`PromoCode` ORDER BY p.`PromoCode` SEPARATOR ',') AS `PromoCodes`
FROM `Customers` c
LEFT JOIN `Promotions` p
    ON p.`IsActive` = 1
GROUP BY c.`CustomerID`, c.`Email`;
