/*
  ScriptID: 0073
  Title: Monthly revenue pivot by store (conditional aggregation)
  Category: report
  Complexity: 8/10
  Tags: PIVOT, reporting
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SET @year := YEAR(NOW());

SELECT
    s.`StoreName`,
    SUM(CASE WHEN MONTH(o.`OrderDate`) = 1  THEN o.`Total` ELSE 0 END) AS `M01`,
    SUM(CASE WHEN MONTH(o.`OrderDate`) = 2  THEN o.`Total` ELSE 0 END) AS `M02`,
    SUM(CASE WHEN MONTH(o.`OrderDate`) = 3  THEN o.`Total` ELSE 0 END) AS `M03`,
    SUM(CASE WHEN MONTH(o.`OrderDate`) = 4  THEN o.`Total` ELSE 0 END) AS `M04`,
    SUM(CASE WHEN MONTH(o.`OrderDate`) = 5  THEN o.`Total` ELSE 0 END) AS `M05`,
    SUM(CASE WHEN MONTH(o.`OrderDate`) = 6  THEN o.`Total` ELSE 0 END) AS `M06`,
    SUM(CASE WHEN MONTH(o.`OrderDate`) = 7  THEN o.`Total` ELSE 0 END) AS `M07`,
    SUM(CASE WHEN MONTH(o.`OrderDate`) = 8  THEN o.`Total` ELSE 0 END) AS `M08`,
    SUM(CASE WHEN MONTH(o.`OrderDate`) = 9  THEN o.`Total` ELSE 0 END) AS `M09`,
    SUM(CASE WHEN MONTH(o.`OrderDate`) = 10 THEN o.`Total` ELSE 0 END) AS `M10`,
    SUM(CASE WHEN MONTH(o.`OrderDate`) = 11 THEN o.`Total` ELSE 0 END) AS `M11`,
    SUM(CASE WHEN MONTH(o.`OrderDate`) = 12 THEN o.`Total` ELSE 0 END) AS `M12`
FROM `Orders` o
JOIN `Stores` s ON s.`StoreID` = o.`StoreID`
WHERE YEAR(o.`OrderDate`) = @year
  AND o.`OrderStatus` IN ('Paid','Shipped','Delivered')
GROUP BY s.`StoreName`
ORDER BY s.`StoreName`;
