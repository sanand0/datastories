/*
  ScriptID: 0090
  Title: Quick look: Products rows
  Category: query
  Complexity: 3/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `CategoryID`, `ProductID`, `IsActive`, `CreatedAt`
FROM `Products`
WHERE `IsActive` = 1
ORDER BY 1 DESC
LIMIT 100;
