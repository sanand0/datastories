/*
  ScriptID: 0029
  Title: Quick look: PageViews rows
  Category: query
  Complexity: 1/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `Referrer`, `CustomerID`, `ViewID`, `Url`, `UserAgent`
FROM `PageViews`
WHERE `ViewedAt` >= DATE_ADD(NOW(, INTERVAL -1 DAY))
ORDER BY 1 DESC
LIMIT 20;
