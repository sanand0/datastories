/*
  ScriptID: 0003
  Title: Quick look: Products rows
  Category: query
  Complexity: 1/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `CategoryID`, `IsActive`, `ProductID`, `UnitPrice`
FROM `Products`
WHERE `IsActive` = 1
ORDER BY 1 DESC
LIMIT 100;
