/*
  ScriptID: 0016
  Title: Sessionize page views into visits (TEMPORARY TABLE)
  Category: analytics
  Complexity: 7/10
  Tags: TEMP, analytics, WINDOW
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

DROP TEMPORARY TABLE IF EXISTS `tmp_pv`;

CREATE TEMPORARY TABLE `tmp_pv` AS
SELECT
    pv.`CustomerID`,
    pv.`ViewedAt`,
    pv.`Url`,
    TIMESTAMPDIFF(MINUTE,
        LAG(pv.`ViewedAt`) OVER (PARTITION BY pv.`CustomerID` ORDER BY pv.`ViewedAt`),
        pv.`ViewedAt`
    ) AS `GapMinutes`
FROM `PageViews` pv
WHERE pv.`ViewedAt` >= DATE_SUB(NOW(), INTERVAL 7 DAY);

SELECT
    `CustomerID`,
    COUNT(*) AS `Views`,
    SUM(CASE WHEN `GapMinutes` IS NULL OR `GapMinutes` > 30 THEN 1 ELSE 0 END) AS `EstimatedSessions`
FROM `tmp_pv`
GROUP BY `CustomerID`
ORDER BY `Views` DESC;
