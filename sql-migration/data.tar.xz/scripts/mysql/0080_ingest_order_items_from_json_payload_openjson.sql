/*
  ScriptID: 0080
  Title: Ingest order items from JSON payload (JSON_TABLE)
  Category: etl
  Complexity: 9/10
  Tags: OPENJSON, JSON, ETL
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SET @orderId := 12345;
SET @items := JSON_ARRAY(
    JSON_OBJECT('ProductID', 10, 'Quantity', 2, 'UnitPrice', 19.99, 'Discount', 0),
    JSON_OBJECT('ProductID', 12, 'Quantity', 1, 'UnitPrice', 249.00, 'Discount', 10.00)
);

INSERT INTO `OrderItems`(`OrderID`,`ProductID`,`Quantity`,`UnitPrice`,`Discount`,`LineTotal`)
SELECT
    @orderId,
    jt.`ProductID`,
    jt.`Quantity`,
    jt.`UnitPrice`,
    jt.`Discount`,
    (jt.`Quantity` * jt.`UnitPrice`) - jt.`Discount` AS `LineTotal`
FROM JSON_TABLE(@items, '$[*]'
    COLUMNS(
        `ProductID` INT PATH '$.ProductID',
        `Quantity` INT PATH '$.Quantity',
        `UnitPrice` DECIMAL(19,4) PATH '$.UnitPrice',
        `Discount` DECIMAL(19,4) PATH '$.Discount'
    )
) AS jt;
