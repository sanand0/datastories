/*
  ScriptID: 0076
  Title: Upsert inventory movements from staging (ON DUPLICATE KEY UPDATE)
  Category: etl
  Complexity: 8/10
  Tags: MERGE, ETL, upsert
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

-- MySQL approach: create a UNIQUE KEY on the natural key, then use INSERT ... ON DUPLICATE KEY UPDATE.
-- Example unique key (run once): ALTER TABLE `InventoryMovements` ADD UNIQUE KEY `UK_Inventory_Natural` (`ProductID`,`StoreID`,`MovedAt`,`Reference`);

INSERT INTO `InventoryMovements`(`ProductID`,`StoreID`,`MovementType`,`Quantity`,`MovedAt`,`Reference`)
SELECT
    s.`ProductID`, s.`StoreID`, s.`MovementType`, s.`Quantity`, s.`MovedAt`, s.`Reference`
FROM `StgInventoryMovements` s
ON DUPLICATE KEY UPDATE
    `Quantity` = VALUES(`Quantity`),
    `MovementType` = VALUES(`MovementType`);
