/*
  ScriptID: 0066
  Title: Stored procedure: capture payment + update order status (handlers)
  Category: procedure
  Complexity: 9/10
  Tags: PROC, TRY/CATCH, TRANSACTION
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

DELIMITER $$

CREATE PROCEDURE `sp_CapturePayment`(
    IN p_OrderID BIGINT,
    IN p_PaymentMethod VARCHAR(20),
    IN p_Amount DECIMAL(19,4),
    IN p_AppUser VARCHAR(80)
)
BEGIN
    DECLARE exit handler for sqlexception
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    SET @app_user := p_AppUser;

    INSERT INTO `Payments`(`OrderID`,`PaymentDate`,`PaymentMethod`,`Amount`,`Status`)
    VALUES(p_OrderID, NOW(3), p_PaymentMethod, p_Amount, 'Captured');

    UPDATE `Orders`
    SET `OrderStatus` = 'Paid'
    WHERE `OrderID` = p_OrderID;

    COMMIT;
END$$

DELIMITER ;
