/*
  ScriptID: 0075
  Title: Quick look: Payments rows
  Category: query
  Complexity: 1/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `PaymentMethod`, `Amount`, `OrderID`
FROM `Payments`
WHERE `Status` = 'Captured'
ORDER BY 1 DESC
LIMIT 50;
