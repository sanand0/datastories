/*
  ScriptID: 0071
  Title: Quick look: Customers rows
  Category: query
  Complexity: 1/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `LastName`, `Status`, `Phone`, `Email`, `CreatedAt`
FROM `Customers`
WHERE `Status` = 'Active'
ORDER BY 1 DESC
LIMIT 50;
