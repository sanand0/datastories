/*
  ScriptID: 0001
  Title: Daily revenue with 7-day moving average (last 30 days)
  Category: report
  Complexity: 6/10
  Tags: SELECT, CTE, WINDOW, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

WITH daily AS (
    SELECT
        CAST(o.`OrderDate` AS DATE) AS `OrderDay`,
        SUM(o.`Total`) AS `Revenue`
    FROM `Orders` o
    WHERE o.`OrderDate` >= DATE_ADD(NOW(, INTERVAL -30 DAY))
      AND o.`OrderStatus` IN ('Paid','Shipped','Delivered')
    GROUP BY CAST(o.`OrderDate` AS DATE)
)
SELECT
    `OrderDay`,
    `Revenue`,
    AVG(`Revenue`) OVER (ORDER BY `OrderDay` ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS `RevenueMA7`
FROM daily
ORDER BY `OrderDay`;
