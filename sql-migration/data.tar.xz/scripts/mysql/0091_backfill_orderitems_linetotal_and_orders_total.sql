/*
  ScriptID: 0091
  Title: Backfill OrderItems.LineTotal and Orders.Total (MySQL rewrite)
  Category: maintenance
  Complexity: 4/10
  Tags: DML, maintenance, TRANSACTION
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

START TRANSACTION;

UPDATE `OrderItems`
SET `LineTotal` = (`Quantity` * `UnitPrice`) - `Discount`
WHERE `LineTotal` IS NULL OR `LineTotal` = 0;

UPDATE `Orders` o
JOIN (
    SELECT
        `OrderID`,
        SUM(`LineTotal`) AS `Subtotal`,
        SUM(`LineTotal`) * 0.08 AS `Tax`,
        CASE WHEN SUM(`LineTotal`) >= 200 THEN 0 ELSE 7.5 END AS `Shipping`,
        SUM(`LineTotal`) * 1.08 + CASE WHEN SUM(`LineTotal`) >= 200 THEN 0 ELSE 7.5 END AS `Total`
    FROM `OrderItems`
    GROUP BY `OrderID`
) x ON x.`OrderID` = o.`OrderID`
SET
    o.`Subtotal` = x.`Subtotal`,
    o.`Tax` = x.`Tax`,
    o.`Shipping` = x.`Shipping`,
    o.`Total` = x.`Total`
WHERE o.`OrderStatus` <> 'Cancelled';

COMMIT;
