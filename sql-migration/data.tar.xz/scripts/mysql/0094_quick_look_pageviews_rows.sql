/*
  ScriptID: 0094
  Title: Quick look: PageViews rows
  Category: query
  Complexity: 3/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `ViewID`, `Referrer`, `CustomerID`, `UserAgent`, `ViewedAt`, `Url`
FROM `PageViews`
WHERE `ViewedAt` >= DATE_ADD(NOW(, INTERVAL -1 DAY))
ORDER BY 1 DESC
LIMIT 100;
