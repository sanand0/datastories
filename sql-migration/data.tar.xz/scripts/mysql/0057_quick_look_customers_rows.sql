/*
  ScriptID: 0057
  Title: Quick look: Customers rows
  Category: query
  Complexity: 2/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `Phone`, `CreatedAt`, `CustomerID`, `Status`, `LastName`, `Email`
FROM `Customers`
WHERE `Status` = 'Active'
ORDER BY 1 DESC
LIMIT 20;
