/*
  ScriptID: 0065
  Title: Quick look: Customers rows
  Category: query
  Complexity: 2/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `LastName`, `CustomerID`, `CreatedAt`, `FirstName`, `Phone`
FROM `Customers`
WHERE `Status` = 'Active' AND `CreatedAt` >= DATE_ADD(NOW(, INTERVAL -30 DAY))
ORDER BY 1 DESC
LIMIT 10;
