/*
  ScriptID: 0058
  Title: Quick look: Products rows
  Category: query
  Complexity: 3/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `SKU`, `CategoryID`, `ProductName`, `CreatedAt`, `UnitPrice`
FROM `Products`
WHERE `IsActive` = 1
ORDER BY 1 DESC
LIMIT 10;
