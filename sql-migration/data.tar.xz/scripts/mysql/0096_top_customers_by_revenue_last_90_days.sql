/*
  ScriptID: 0096
  Title: Top customers by revenue (last 90 days)
  Category: query
  Complexity: 6/10
  Tags: SELECT, join, aggregate, CTE, WINDOW, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

WITH recent_orders AS (
    SELECT
        o.`OrderID`,
        o.`CustomerID`,
        o.`OrderDate`,
        o.`Total`
    FROM `Orders` o
    WHERE o.`OrderDate` >= DATE_ADD(NOW(, INTERVAL -90 DAY))
      AND o.`OrderStatus` IN ('Paid','Shipped','Delivered')
)
SELECT c.`CustomerID`,
    c.`FirstName`,
    c.`LastName`,
    SUM(ro.`Total`) AS `Revenue`,
    COUNT(DISTINCT ro.`OrderID`) AS `Orders`,
    ROW_NUMBER() OVER (ORDER BY SUM(ro.`Total`) DESC) AS `RankByRevenue`
FROM recent_orders ro
JOIN `Customers` c ON c.`CustomerID` = ro.`CustomerID`
GROUP BY c.`CustomerID`, c.`FirstName`, c.`LastName`
ORDER BY `Revenue` DESC
LIMIT 100;
