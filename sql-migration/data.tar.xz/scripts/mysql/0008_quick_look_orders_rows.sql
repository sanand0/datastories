/*
  ScriptID: 0008
  Title: Quick look: Orders rows
  Category: query
  Complexity: 2/10
  Tags: SELECT, simple, TOP, DATEADD, IN
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `CustomerID`, `Tax`, `OrderID`
FROM `Orders`
WHERE `OrderDate` >= DATE_ADD(NOW(, INTERVAL -7 DAY)) AND `OrderStatus` IN ('Paid','Shipped')
ORDER BY 1 DESC
LIMIT 50;
