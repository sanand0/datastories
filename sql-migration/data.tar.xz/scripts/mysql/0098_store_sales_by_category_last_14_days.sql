/*
  ScriptID: 0098
  Title: Store sales by category (last 14 days)
  Category: report
  Complexity: 6/10
  Tags: SELECT, join, groupby, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT s.`StoreName`,
    cat.`CategoryName`,
    SUM(oi.`LineTotal`) AS `Revenue`,
    SUM(oi.`Quantity`) AS `Units`,
    COUNT(DISTINCT o.`OrderID`) AS `Orders`
FROM `Orders` o
JOIN `Stores` s ON s.`StoreID` = o.`StoreID`
JOIN `OrderItems` oi ON oi.`OrderID` = o.`OrderID`
JOIN `Products` p ON p.`ProductID` = oi.`ProductID`
JOIN `Categories` cat ON cat.`CategoryID` = p.`CategoryID`
WHERE o.`OrderDate` >= DATE_ADD(NOW(, INTERVAL -14 DAY))
  AND o.`OrderStatus` IN ('Paid','Shipped','Delivered')
  AND p.`IsActive` = 1
GROUP BY s.`StoreName`, cat.`CategoryName`
ORDER BY `Revenue` DESC
LIMIT 200;
