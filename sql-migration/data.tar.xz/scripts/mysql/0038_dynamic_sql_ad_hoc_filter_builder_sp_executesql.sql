/*
  ScriptID: 0038
  Title: Dynamic SQL: ad-hoc filter builder (PREPARE)
  Category: query
  Complexity: 10/10
  Tags: dynamic_sql, sp_executesql
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SET @fromDate := DATE_SUB(NOW(3), INTERVAL 30 DAY);
SET @status := 'Paid';

SET @sql := '
    SELECT
        o.`OrderID`, o.`OrderDate`, o.`Total`
    FROM `Orders` o
    WHERE o.`OrderDate` >= ?
      AND o.`OrderStatus` = ?
    ORDER BY o.`OrderDate` DESC
    LIMIT 50
';

PREPARE stmt FROM @sql;
EXECUTE stmt USING @fromDate, @status;
DEALLOCATE PREPARE stmt;
