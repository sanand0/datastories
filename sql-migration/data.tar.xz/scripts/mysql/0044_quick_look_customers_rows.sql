/*
  ScriptID: 0044
  Title: Quick look: Customers rows
  Category: query
  Complexity: 2/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `Status`, `LastName`, `CustomerID`, `FirstName`, `Phone`, `CreatedAt`
FROM `Customers`
WHERE `Status` = 'Active'
ORDER BY 1 DESC
LIMIT 20;
