/*
  ScriptID: 0087
  Title: Quick look: Payments rows
  Category: query
  Complexity: 3/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `PaymentMethod`, `TxnRef`, `Status`, `OrderID`, `PaymentDate`
FROM `Payments`
WHERE `Status` = 'Captured'
ORDER BY 1 DESC
LIMIT 100;
