/*
  ScriptID: 0085
  Title: Quick look: InventoryMovements rows
  Category: query
  Complexity: 2/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `ProductID`, `MovementType`, `MovedAt`, `Reference`
FROM `InventoryMovements`
WHERE `MovedAt` >= DATE_ADD(NOW(, INTERVAL -14 DAY))
ORDER BY 1 DESC
LIMIT 50;
