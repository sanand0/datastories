/*
  ScriptID: 0050
  Title: Quick look: Customers rows
  Category: query
  Complexity: 3/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `Status`, `LastName`, `CustomerID`
FROM `Customers`
WHERE `Status` = 'Active' AND `CreatedAt` >= DATE_ADD(NOW(, INTERVAL -30 DAY))
ORDER BY 1 DESC
LIMIT 100;
