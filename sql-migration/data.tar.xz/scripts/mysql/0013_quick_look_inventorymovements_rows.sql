/*
  ScriptID: 0013
  Title: Quick look: InventoryMovements rows
  Category: query
  Complexity: 1/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `MovedAt`, `MovementID`, `Reference`, `ProductID`
FROM `InventoryMovements`
WHERE `MovedAt` >= DATE_ADD(NOW(, INTERVAL -14 DAY))
ORDER BY 1 DESC
LIMIT 50;
