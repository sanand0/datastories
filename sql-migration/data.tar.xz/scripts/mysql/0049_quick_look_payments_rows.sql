/*
  ScriptID: 0049
  Title: Quick look: Payments rows
  Category: query
  Complexity: 2/10
  Tags: SELECT, simple, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `PaymentMethod`, `Status`, `Amount`, `TxnRef`, `PaymentID`
FROM `Payments`
WHERE `Status` = 'Captured'
ORDER BY 1 DESC
LIMIT 20;
