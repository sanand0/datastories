/*
  ScriptID: 0028
  Title: Quick look: PageViews rows
  Category: query
  Complexity: 2/10
  Tags: SELECT, simple, TOP, DATEADD
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `UserAgent`, `Url`, `ViewID`, `CustomerID`, `Referrer`
FROM `PageViews`
WHERE `ViewedAt` >= DATE_ADD(NOW(, INTERVAL -1 DAY))
ORDER BY 1 DESC
LIMIT 20;
