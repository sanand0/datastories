/*
  ScriptID: 0015
  Title: Ad-hoc troubleshooting query (NOLOCK)
  Category: query
  Complexity: 6/10
  Tags: NOLOCK, performance, TOP
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT o.`OrderID`, o.`OrderDate`, o.`OrderStatus`, o.`Total`
FROM `Orders` o 
WHERE o.`OrderStatus` = 'Paid'
ORDER BY o.`OrderDate` DESC
LIMIT 100;
