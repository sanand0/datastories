/*
  ScriptID: 0031
  Title: Quick look: Orders rows
  Category: query
  Complexity: 3/10
  Tags: SELECT, simple, TOP, DATEADD, IN
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SELECT `OrderID`, `OrderDate`, `OrderStatus`, `Total`
FROM `Orders`
WHERE `OrderDate` >= DATE_ADD(NOW(, INTERVAL -7 DAY)) AND `OrderStatus` IN ('Paid','Shipped')
ORDER BY 1 DESC
LIMIT 10;
