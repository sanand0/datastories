/*
  ScriptID: 0046
  Title: Filter customers by comma-separated status list (FIND_IN_SET)
  Category: query
  Complexity: 9/10
  Tags: CROSS APPLY, STRING_SPLIT, reporting
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

SET @statuses := 'Active,Churned,Prospect';

SELECT
    c.`CustomerID`, c.`FirstName`, c.`LastName`, c.`Status`
FROM `Customers` c
WHERE FIND_IN_SET(c.`Status`, @statuses) > 0
ORDER BY c.`CustomerID`;

-- For large lists: normalize into a table (recommended) instead of CSV parsing.
