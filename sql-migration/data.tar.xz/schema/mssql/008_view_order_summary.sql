/*
  ScriptID: 0008
  Title: View: order summary for reporting
  Category: schema
  Complexity: 5/10
  Tags: DDL, view, reporting
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

USE [RetailOps];
GO

CREATE OR ALTER VIEW [dbo].[vw_OrderSummary]
AS
SELECT
    o.[OrderID],
    o.[OrderDate],
    o.[OrderStatus],
    c.[CustomerID],
    c.[FirstName],
    c.[LastName],
    o.[Total],
    SUM(oi.[Quantity]) AS [ItemCount]
FROM [dbo].[Orders] o
JOIN [dbo].[Customers] c ON c.[CustomerID] = o.[CustomerID]
JOIN [dbo].[OrderItems] oi ON oi.[OrderID] = o.[OrderID]
GROUP BY o.[OrderID], o.[OrderDate], o.[OrderStatus], c.[CustomerID], c.[FirstName], c.[LastName], o.[Total];
GO
