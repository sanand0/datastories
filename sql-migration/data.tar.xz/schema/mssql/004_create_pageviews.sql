/*
  ScriptID: 0004
  Title: Create web analytics table (page views)
  Category: schema
  Complexity: 3/10
  Tags: DDL, tables
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

USE [RetailOps];
GO

CREATE TABLE [dbo].[PageViews](
    [ViewID] BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [CustomerID] INT NULL,
    [Url] NVARCHAR(400) NOT NULL,
    [ViewedAt] DATETIME2(3) NOT NULL CONSTRAINT DF_PageViews_ViewedAt DEFAULT (SYSDATETIME()),
    [Referrer] NVARCHAR(400) NULL,
    [UserAgent] NVARCHAR(400) NULL
);
