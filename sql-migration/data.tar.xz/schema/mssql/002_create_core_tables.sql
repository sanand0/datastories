/*
  ScriptID: 0002
  Title: Create core tables (customers, products, orders)
  Category: schema
  Complexity: 6/10
  Tags: DDL, tables
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

USE [RetailOps];
GO

CREATE TABLE [dbo].[Customers](
    [CustomerID] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [FirstName] NVARCHAR(50) NOT NULL,
    [LastName] NVARCHAR(50) NOT NULL,
    [Email] NVARCHAR(254) NOT NULL UNIQUE,
    [Phone] NVARCHAR(30) NULL,
    [Status] NVARCHAR(20) NOT NULL CONSTRAINT DF_Customers_Status DEFAULT ('Active'),
    [CreatedAt] DATETIME2(3) NOT NULL CONSTRAINT DF_Customers_CreatedAt DEFAULT (SYSDATETIME())
);

CREATE TABLE [dbo].[Categories](
    [CategoryID] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [ParentCategoryID] INT NULL,
    [CategoryName] NVARCHAR(100) NOT NULL,
    [IsActive] BIT NOT NULL CONSTRAINT DF_Categories_IsActive DEFAULT (1)
);

CREATE TABLE [dbo].[Products](
    [ProductID] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [CategoryID] INT NOT NULL,
    [SKU] NVARCHAR(40) NOT NULL UNIQUE,
    [ProductName] NVARCHAR(200) NOT NULL,
    [UnitPrice] MONEY NOT NULL,
    [IsActive] BIT NOT NULL CONSTRAINT DF_Products_IsActive DEFAULT (1),
    [CreatedAt] DATETIME2(3) NOT NULL CONSTRAINT DF_Products_CreatedAt DEFAULT (SYSDATETIME()),
    CONSTRAINT FK_Products_Categories FOREIGN KEY ([CategoryID]) REFERENCES [dbo].[Categories]([CategoryID])
);

CREATE TABLE [dbo].[Stores](
    [StoreID] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [StoreName] NVARCHAR(120) NOT NULL,
    [City] NVARCHAR(60) NOT NULL,
    [Country] NVARCHAR(60) NOT NULL,
    [OpenedAt] DATE NOT NULL,
    [IsActive] BIT NOT NULL CONSTRAINT DF_Stores_IsActive DEFAULT (1)
);

CREATE TABLE [dbo].[Orders](
    [OrderID] BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [CustomerID] INT NOT NULL,
    [StoreID] INT NOT NULL,
    [OrderDate] DATETIME2(3) NOT NULL CONSTRAINT DF_Orders_OrderDate DEFAULT (SYSDATETIME()),
    [OrderStatus] NVARCHAR(20) NOT NULL,
    [Subtotal] MONEY NOT NULL,
    [Tax] MONEY NOT NULL,
    [Shipping] MONEY NOT NULL,
    [Total] MONEY NOT NULL,
    CONSTRAINT FK_Orders_Customers FOREIGN KEY ([CustomerID]) REFERENCES [dbo].[Customers]([CustomerID]),
    CONSTRAINT FK_Orders_Stores FOREIGN KEY ([StoreID]) REFERENCES [dbo].[Stores]([StoreID])
);

CREATE TABLE [dbo].[OrderItems](
    [OrderItemID] BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [OrderID] BIGINT NOT NULL,
    [ProductID] INT NOT NULL,
    [Quantity] INT NOT NULL,
    [UnitPrice] MONEY NOT NULL,
    [Discount] MONEY NOT NULL CONSTRAINT DF_OrderItems_Discount DEFAULT (0),
    [LineTotal] MONEY NOT NULL,
    CONSTRAINT FK_OrderItems_Orders FOREIGN KEY ([OrderID]) REFERENCES [dbo].[Orders]([OrderID]),
    CONSTRAINT FK_OrderItems_Products FOREIGN KEY ([ProductID]) REFERENCES [dbo].[Products]([ProductID])
);
