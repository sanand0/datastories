/*
  ScriptID: 0003
  Title: Create operational tables (payments, inventory, audit)
  Category: schema
  Complexity: 6/10
  Tags: DDL, tables
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

USE [RetailOps];
GO

CREATE TABLE [dbo].[Payments](
    [PaymentID] BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [OrderID] BIGINT NOT NULL,
    [PaymentDate] DATETIME2(3) NOT NULL,
    [PaymentMethod] NVARCHAR(20) NOT NULL,
    [Amount] MONEY NOT NULL,
    [Status] NVARCHAR(20) NOT NULL,
    [TxnRef] UNIQUEIDENTIFIER NOT NULL CONSTRAINT DF_Payments_TxnRef DEFAULT (NEWID()),
    CONSTRAINT FK_Payments_Orders FOREIGN KEY ([OrderID]) REFERENCES [dbo].[Orders]([OrderID])
);

CREATE TABLE [dbo].[InventoryMovements](
    [MovementID] BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [ProductID] INT NOT NULL,
    [StoreID] INT NOT NULL,
    [MovementType] NVARCHAR(20) NOT NULL,
    [Quantity] INT NOT NULL,
    [MovedAt] DATETIME2(3) NOT NULL CONSTRAINT DF_Inventory_MovedAt DEFAULT (SYSDATETIME()),
    [Reference] NVARCHAR(120) NULL,
    CONSTRAINT FK_Inventory_Products FOREIGN KEY ([ProductID]) REFERENCES [dbo].[Products]([ProductID]),
    CONSTRAINT FK_Inventory_Stores FOREIGN KEY ([StoreID]) REFERENCES [dbo].[Stores]([StoreID])
);

CREATE TABLE [dbo].[AuditLog](
    [AuditID] BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [EntityName] NVARCHAR(60) NOT NULL,
    [EntityID] NVARCHAR(60) NOT NULL,
    [Action] NVARCHAR(20) NOT NULL,
    [ChangedAt] DATETIME2(3) NOT NULL CONSTRAINT DF_Audit_ChangedAt DEFAULT (SYSDATETIME()),
    [ChangedBy] NVARCHAR(80) NOT NULL,
    [ChangeJson] NVARCHAR(MAX) NULL
);

CREATE TABLE [dbo].[UserSessions](
    [SessionID] BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [UserName] NVARCHAR(80) NOT NULL,
    [HostName] NVARCHAR(80) NOT NULL,
    [AppName] NVARCHAR(80) NOT NULL,
    [LoginAt] DATETIME2(3) NOT NULL,
    [LogoutAt] DATETIME2(3) NULL,
    [IsActive] BIT NOT NULL CONSTRAINT DF_UserSessions_IsActive DEFAULT (1)
);
