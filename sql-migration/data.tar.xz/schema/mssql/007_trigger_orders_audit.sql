/*
  ScriptID: 0007
  Title: Trigger: audit order status changes
  Category: schema
  Complexity: 8/10
  Tags: DDL, trigger, audit
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

USE [RetailOps];
GO

CREATE OR ALTER TRIGGER [dbo].[trg_Orders_AuditStatus]
ON [dbo].[Orders]
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF UPDATE([OrderStatus])
    BEGIN
        INSERT INTO [dbo].[AuditLog]([EntityName],[EntityID],[Action],[ChangedAt],[ChangedBy],[ChangeJson])
        SELECT
            N'Orders',
            CAST(i.[OrderID] AS NVARCHAR(60)),
            N'UPDATE',
            SYSDATETIME(),
            COALESCE(SESSION_CONTEXT(N'app_user'), SUSER_SNAME()),
            CONCAT(N'{"old":"', d.[OrderStatus], N'","new":"', i.[OrderStatus], N'"}')
        FROM inserted i
        JOIN deleted d ON d.[OrderID] = i.[OrderID];
    END
END
GO
