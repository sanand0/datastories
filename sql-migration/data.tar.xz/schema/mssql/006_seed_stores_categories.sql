/*
  ScriptID: 0006
  Title: Seed: stores and categories
  Category: schema
  Complexity: 4/10
  Tags: DML, seed
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

USE [RetailOps];
GO

INSERT INTO [dbo].[Stores]([StoreName],[City],[Country],[OpenedAt],[IsActive]) VALUES
  (N'HarborFront', N'Singapore', N'SG', '2018-06-01', 1),
  (N'Orchard', N'Singapore', N'SG', '2016-11-12', 1),
  (N'Marina', N'Singapore', N'SG', '2020-02-02', 1);

INSERT INTO [dbo].[Categories]([ParentCategoryID],[CategoryName],[IsActive]) VALUES
  (NULL, N'Electronics', 1),
  (NULL, N'Home', 1),
  (NULL, N'Grocery', 1),
  (1, N'Audio', 1),
  (1, N'Computing', 1);
