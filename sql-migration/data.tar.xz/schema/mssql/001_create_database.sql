/*
  ScriptID: 0001
  Title: Create database and base schema
  Category: schema
  Complexity: 3/10
  Tags: DDL, schema
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

IF DB_ID(N'RetailOps') IS NULL
BEGIN
    CREATE DATABASE [RetailOps];
END
GO

USE [RetailOps];
GO

CREATE SCHEMA [dbo];
GO
