/*
  ScriptID: 0005
  Title: Indexes for reporting workloads
  Category: schema
  Complexity: 5/10
  Tags: DDL, indexes
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

USE [RetailOps];
GO

CREATE INDEX IX_Orders_OrderDate ON [dbo].[Orders]([OrderDate]);
CREATE INDEX IX_OrderItems_OrderID ON [dbo].[OrderItems]([OrderID]);
CREATE INDEX IX_OrderItems_ProductID ON [dbo].[OrderItems]([ProductID]);
CREATE INDEX IX_Payments_OrderID ON [dbo].[Payments]([OrderID]);
CREATE INDEX IX_Inventory_ProductStore ON [dbo].[InventoryMovements]([ProductID],[StoreID],[MovedAt]);
CREATE INDEX IX_PageViews_ViewedAt ON [dbo].[PageViews]([ViewedAt]);
