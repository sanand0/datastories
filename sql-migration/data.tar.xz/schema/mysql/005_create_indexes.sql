/*
  ScriptID: 0005
  Title: Indexes for reporting workloads
  Category: schema
  Complexity: 5/10
  Tags: DDL, indexes
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

CREATE INDEX `IX_Orders_OrderDate` ON `Orders`(`OrderDate`);
CREATE INDEX `IX_OrderItems_OrderID` ON `OrderItems`(`OrderID`);
CREATE INDEX `IX_OrderItems_ProductID` ON `OrderItems`(`ProductID`);
CREATE INDEX `IX_Payments_OrderID` ON `Payments`(`OrderID`);
CREATE INDEX `IX_Inventory_ProductStore` ON `InventoryMovements`(`ProductID`,`StoreID`,`MovedAt`);
CREATE INDEX `IX_PageViews_ViewedAt` ON `PageViews`(`ViewedAt`);
