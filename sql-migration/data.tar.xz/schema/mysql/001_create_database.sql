/*
  ScriptID: 0001
  Title: Create database and base schema
  Category: schema
  Complexity: 3/10
  Tags: DDL, schema
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

CREATE DATABASE IF NOT EXISTS `RetailOps` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
-- USE `RetailOps`;  -- choose DB in your client/session
