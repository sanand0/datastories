/*
  ScriptID: 0004
  Title: Create web analytics table (page views)
  Category: schema
  Complexity: 3/10
  Tags: DDL, tables
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

CREATE TABLE IF NOT EXISTS `PageViews`(
    `ViewID` BIGINT NOT NULL AUTO_INCREMENT,
    `CustomerID` INT NULL,
    `Url` VARCHAR(400) NOT NULL,
    `ViewedAt` DATETIME(3) NOT NULL DEFAULT NOW(3),
    `Referrer` VARCHAR(400) NULL,
    `UserAgent` VARCHAR(400) NULL,
    PRIMARY KEY (`ViewID`),
    KEY `IX_PageViews_CustomerID` (`CustomerID`)
) ENGINE=InnoDB;
