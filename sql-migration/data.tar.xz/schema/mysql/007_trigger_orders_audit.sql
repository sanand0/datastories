/*
  ScriptID: 0007
  Title: Trigger: audit order status changes
  Category: schema
  Complexity: 8/10
  Tags: DDL, trigger, audit
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

DELIMITER $$

CREATE TRIGGER `trg_Orders_AuditStatus`
AFTER UPDATE ON `Orders`
FOR EACH ROW
BEGIN
    IF (OLD.`OrderStatus` <> NEW.`OrderStatus`) THEN
        INSERT INTO `AuditLog`(`EntityName`,`EntityID`,`Action`,`ChangedAt`,`ChangedBy`,`ChangeJson`)
        VALUES(
            'Orders',
            CAST(NEW.`OrderID` AS CHAR(60)),
            'UPDATE',
            NOW(3),
            COALESCE(@app_user, USER()),
            CONCAT('{"old":"', OLD.`OrderStatus`, '","new":"', NEW.`OrderStatus`, '"}')
        );
    END IF;
END$$

DELIMITER ;
