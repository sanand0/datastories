/*
  ScriptID: 0008
  Title: View: order summary for reporting
  Category: schema
  Complexity: 5/10
  Tags: DDL, view, reporting
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

CREATE OR REPLACE VIEW `vw_OrderSummary` AS
SELECT
    o.`OrderID`,
    o.`OrderDate`,
    o.`OrderStatus`,
    c.`CustomerID`,
    c.`FirstName`,
    c.`LastName`,
    o.`Total`,
    SUM(oi.`Quantity`) AS `ItemCount`
FROM `Orders` o
JOIN `Customers` c ON c.`CustomerID` = o.`CustomerID`
JOIN `OrderItems` oi ON oi.`OrderID` = o.`OrderID`
GROUP BY o.`OrderID`, o.`OrderDate`, o.`OrderStatus`, c.`CustomerID`, c.`FirstName`, c.`LastName`, o.`Total`;
