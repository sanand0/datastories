/*
  ScriptID: 0003
  Title: Create operational tables (payments, inventory, audit)
  Category: schema
  Complexity: 6/10
  Tags: DDL, tables
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

CREATE TABLE IF NOT EXISTS `Payments`(
    `PaymentID` BIGINT NOT NULL AUTO_INCREMENT,
    `OrderID` BIGINT NOT NULL,
    `PaymentDate` DATETIME(3) NOT NULL,
    `PaymentMethod` VARCHAR(20) NOT NULL,
    `Amount` DECIMAL(19,4) NOT NULL,
    `Status` VARCHAR(20) NOT NULL,
    `TxnRef` CHAR(36) NOT NULL DEFAULT (UUID()),
    PRIMARY KEY (`PaymentID`),
    KEY `IX_Payments_OrderID` (`OrderID`),
    CONSTRAINT `FK_Payments_Orders` FOREIGN KEY (`OrderID`) REFERENCES `Orders`(`OrderID`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `InventoryMovements`(
    `MovementID` BIGINT NOT NULL AUTO_INCREMENT,
    `ProductID` INT NOT NULL,
    `StoreID` INT NOT NULL,
    `MovementType` VARCHAR(20) NOT NULL,
    `Quantity` INT NOT NULL,
    `MovedAt` DATETIME(3) NOT NULL DEFAULT NOW(3),
    `Reference` VARCHAR(120) NULL,
    PRIMARY KEY (`MovementID`),
    KEY `IX_Inventory_ProductID` (`ProductID`),
    KEY `IX_Inventory_StoreID` (`StoreID`),
    CONSTRAINT `FK_Inventory_Products` FOREIGN KEY (`ProductID`) REFERENCES `Products`(`ProductID`),
    CONSTRAINT `FK_Inventory_Stores` FOREIGN KEY (`StoreID`) REFERENCES `Stores`(`StoreID`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `AuditLog`(
    `AuditID` BIGINT NOT NULL AUTO_INCREMENT,
    `EntityName` VARCHAR(60) NOT NULL,
    `EntityID` VARCHAR(60) NOT NULL,
    `Action` VARCHAR(20) NOT NULL,
    `ChangedAt` DATETIME(3) NOT NULL DEFAULT NOW(3),
    `ChangedBy` VARCHAR(80) NOT NULL,
    `ChangeJson` LONGTEXT NULL,
    PRIMARY KEY (`AuditID`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `UserSessions`(
    `SessionID` BIGINT NOT NULL AUTO_INCREMENT,
    `UserName` VARCHAR(80) NOT NULL,
    `HostName` VARCHAR(80) NOT NULL,
    `AppName` VARCHAR(80) NOT NULL,
    `LoginAt` DATETIME(3) NOT NULL,
    `LogoutAt` DATETIME(3) NULL,
    `IsActive` TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (`SessionID`)
) ENGINE=InnoDB;
