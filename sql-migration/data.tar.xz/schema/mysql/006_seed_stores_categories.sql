/*
  ScriptID: 0006
  Title: Seed: stores and categories
  Category: schema
  Complexity: 4/10
  Tags: DML, seed
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

INSERT INTO `Stores`(`StoreName`,`City`,`Country`,`OpenedAt`,`IsActive`) VALUES
  ('HarborFront', 'Singapore', 'SG', '2018-06-01', 1),
  ('Orchard', 'Singapore', 'SG', '2016-11-12', 1),
  ('Marina', 'Singapore', 'SG', '2020-02-02', 1);

INSERT INTO `Categories`(`ParentCategoryID`,`CategoryName`,`IsActive`) VALUES
  (NULL, 'Electronics', 1),
  (NULL, 'Home', 1),
  (NULL, 'Grocery', 1),
  (1, 'Audio', 1),
  (1, 'Computing', 1);
