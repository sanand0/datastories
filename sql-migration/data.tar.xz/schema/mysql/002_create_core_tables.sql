/*
  ScriptID: 0002
  Title: Create core tables (customers, products, orders)
  Category: schema
  Complexity: 6/10
  Tags: DDL, tables
  GeneratedFor: MSSQL -> MySQL migration demo (LLM + coding agents)
*/

CREATE TABLE IF NOT EXISTS `Customers`(
    `CustomerID` INT NOT NULL AUTO_INCREMENT,
    `FirstName` VARCHAR(50) NOT NULL,
    `LastName` VARCHAR(50) NOT NULL,
    `Email` VARCHAR(254) NOT NULL,
    `Phone` VARCHAR(30) NULL,
    `Status` VARCHAR(20) NOT NULL DEFAULT 'Active',
    `CreatedAt` DATETIME(3) NOT NULL DEFAULT NOW(3),
    PRIMARY KEY (`CustomerID`),
    UNIQUE KEY `UK_Customers_Email` (`Email`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `Categories`(
    `CategoryID` INT NOT NULL AUTO_INCREMENT,
    `ParentCategoryID` INT NULL,
    `CategoryName` VARCHAR(100) NOT NULL,
    `IsActive` TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (`CategoryID`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `Products`(
    `ProductID` INT NOT NULL AUTO_INCREMENT,
    `CategoryID` INT NOT NULL,
    `SKU` VARCHAR(40) NOT NULL,
    `ProductName` VARCHAR(200) NOT NULL,
    `UnitPrice` DECIMAL(19,4) NOT NULL,
    `IsActive` TINYINT(1) NOT NULL DEFAULT 1,
    `CreatedAt` DATETIME(3) NOT NULL DEFAULT NOW(3),
    PRIMARY KEY (`ProductID`),
    UNIQUE KEY `UK_Products_SKU` (`SKU`),
    KEY `IX_Products_CategoryID` (`CategoryID`),
    CONSTRAINT `FK_Products_Categories` FOREIGN KEY (`CategoryID`) REFERENCES `Categories`(`CategoryID`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `Stores`(
    `StoreID` INT NOT NULL AUTO_INCREMENT,
    `StoreName` VARCHAR(120) NOT NULL,
    `City` VARCHAR(60) NOT NULL,
    `Country` VARCHAR(60) NOT NULL,
    `OpenedAt` DATE NOT NULL,
    `IsActive` TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (`StoreID`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `Orders`(
    `OrderID` BIGINT NOT NULL AUTO_INCREMENT,
    `CustomerID` INT NOT NULL,
    `StoreID` INT NOT NULL,
    `OrderDate` DATETIME(3) NOT NULL DEFAULT NOW(3),
    `OrderStatus` VARCHAR(20) NOT NULL,
    `Subtotal` DECIMAL(19,4) NOT NULL,
    `Tax` DECIMAL(19,4) NOT NULL,
    `Shipping` DECIMAL(19,4) NOT NULL,
    `Total` DECIMAL(19,4) NOT NULL,
    PRIMARY KEY (`OrderID`),
    KEY `IX_Orders_CustomerID` (`CustomerID`),
    KEY `IX_Orders_StoreID` (`StoreID`),
    CONSTRAINT `FK_Orders_Customers` FOREIGN KEY (`CustomerID`) REFERENCES `Customers`(`CustomerID`),
    CONSTRAINT `FK_Orders_Stores` FOREIGN KEY (`StoreID`) REFERENCES `Stores`(`StoreID`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `OrderItems`(
    `OrderItemID` BIGINT NOT NULL AUTO_INCREMENT,
    `OrderID` BIGINT NOT NULL,
    `ProductID` INT NOT NULL,
    `Quantity` INT NOT NULL,
    `UnitPrice` DECIMAL(19,4) NOT NULL,
    `Discount` DECIMAL(19,4) NOT NULL DEFAULT 0,
    `LineTotal` DECIMAL(19,4) NOT NULL,
    PRIMARY KEY (`OrderItemID`),
    KEY `IX_OrderItems_OrderID` (`OrderID`),
    KEY `IX_OrderItems_ProductID` (`ProductID`),
    CONSTRAINT `FK_OrderItems_Orders` FOREIGN KEY (`OrderID`) REFERENCES `Orders`(`OrderID`),
    CONSTRAINT `FK_OrderItems_Products` FOREIGN KEY (`ProductID`) REFERENCES `Products`(`ProductID`)
) ENGINE=InnoDB;
